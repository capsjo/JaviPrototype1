<html>
    <head></head>
    <body>
        <?php
        $response = array();
        // Delete a user
        if (isset($_POST["username"])) {
            $username = $_POST["username"];
            
            require_once __DIR__ . "/connect.php";
            
            $db = new Database_Connection();
            $connect = $db -> getLink();
            
            $result = mysqli_query($connect,"DELETE FROM users WHERE username = '$username'");
            if ($result) {
                $response["success"] = true;
                $response["message"] = "Successfully deleted a user";
            }
            else {
                $response["success"] = false;
                $response["message"] = "Failed to delete a user";
            }
            echo json_encode($response);
        }
        // Delete a restaurant
        else if (isset($_POST["restaurant_id"])
            $restaurant_id = $_POST["restaurant_id"];
            
            require_once __DIR__ . "/connect.php";
            
            $db = new Database_Connection();
            $connect = $db -> getLink();
            
            $result = mysqli_query($connect, "DELETE FROM restaurants WHERE restaurant_id = '$restaurant_id'");
            if ($result) {
                $response["success"] = true;
                $response["message"] = "Successfully deleted a restaurant";
            }
            else {
                $response["success"] = false;
                $response["message"] = "Failed to delete a restaurant";
            }
            echo json_encode($response);
        }
        // Delete a photo
        else if (isset($_POST["photo_id"])) {
            $photo_id = $_POST["photo_id"];
            
            require_once __DIR__ . "/connect.php";
            
            $db = new Database_Connection();
            $connect = $db -> getLink();
            
            $result = mysqli_query($connect,"DELETE FROM photos WHERE photo_id = '$photo_id'");
            if ($result) {
                $response["success"] = true;
                $response["message"] = "Successfully deleted a user";
            }
            else {
                $response["success"] = false;
                $response["message"] = "Failed to delete a user";
            }
            echo json_encode($response);
        }
        // Delete a publication
        else if (isset($_POST["publication_id"])) {
            $publication_id = $_POST["publication_id"];
            
            require_once __DIR__ . "/connect.php";
            
            $db = new Database_Connection();
            $connect = $db -> getLink();
            
            $result = mysqli_query($connect, "DELETE FROM publications WHERE publication_id = '$publication_id'");
            
            if ($result) {
                $response["success"] = true;
                $response["message"] = "Successfully added a publication";
            }
            else {
                $response["success"] = false;
                $response["message"] = "Failed to add a publication";
            }
            echo json_encode($response);
        }
        else {
            // Missing fields
            $response["message"] = "Required field(s) is missing";
            echo json_encode($response);
        }
        ?>
    </body>
</html>