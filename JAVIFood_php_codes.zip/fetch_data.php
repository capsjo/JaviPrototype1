<html>
    <head></head>
    <body>
        <?php
        $response = array();
        // Sign in
        if (isset($_GET["username"]) && isset($_GET["password"])) {
            $username = $_GET["username"];
            $password = $_GET["password"];
            
            require_once __DIR__ . "/connect.php";
            
            $db = new Database_Connection();
            $connect = $db -> getLink();
            
            $result = mysqli_query($connect,"SELECT username, password from User WHERE username = '$username' AND password = '$password'");
            if ($result) {
                $userInfo = mysqli_fetch_array($result, MYSQLI_ASSOC);
                $userConfirm = $userInfo["username"];
                $passConfirm = $userInfo["password"];
                if (($username == $userConfirm && $password == $passConfirm) && ($username != null && $password != null)) {
                    $response["success"] = true;
                    $response["message"] = "Authentification successful";
                }
                else {
                    $response["success"] = false;
                    $response["message"] = "Authentification failed";
                }
            }
        }
        else if (isset($_GET["showMostRecent"]) && isset($_GET["username"])) {
            $mostRecent = $_GET["showMostRecent"];
            $username = $_GET["username"];
            
            if ($mostRecent != null) {
                require_once __DIR__ . "/connect.php";
            
                $db = new Database_Connection();
                $connect = $db -> getLink();
            
                $result = mysqli_query($connect, "SELECT * FROM Photo WHERE username = '$username' ORDER BY id DESC LIMIT $mostRecent");
                if ($result) {
                    $response["recentImg"] = array();
                    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                        array_push($response["recentImg"], $row);
                    }
                    $response["success"] = true;
                    $response["message"] = "Successfully fetched photos";
                }
                else {
                    $response["success"] = false;
                    $response["message"] = "Failed to fetch photos";
                }
            }
        }
        else if (isset($_GET["username"])) {
            $username = $_GET["username"];
            
            require_once __DIR__ . "/connect.php";
            
            $db = new Database_Connection();
            $connect = $db -> getLink();
            
            $result = mysqli_query($connect,"SELECT * from Photo WHERE username = '$username'");
            if ($result) {
                $response["userimg"] = array();
                while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    array_push($response["userimg"], $row);
                }
                $response["success"] = true;
                $response["message"] = "Successfully fetched photos";
            }
            else {
                $response["success"] = false;
                $response["message"] = "Failed to fetch photos";
            }
        }
        else if (isset($_GET["showMostRecent"])) {
            $mostRecent = $_GET["showMostRecent"];
            
            if ($mostRecent != null) {
                require_once __DIR__ . "/connect.php";
            
                $db = new Database_Connection();
                $connect = $db -> getLink();
            
                $result = mysqli_query($connect, "SELECT * FROM Photo ORDER BY id DESC LIMIT $mostRecent");
                if ($result) {
                    $response["recentImg"] = array();
                    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                        array_push($response["recentImg"], $row);
                    }
                    $response["success"] = true;
                    $response["message"] = "Successfully fetched photos";
                }
                else {
                    $response["success"] = false;
                    $response["message"] = "Failed to fetch photos";
                }
            }
        }
        else {
            // Missing fields
            $response["message"] = "Required field(s) is missing";
        }
        echo json_encode($response);
        ?>
    </body>
</html>