<html>
    <head>
    </head>
    <body>
        <?php
        $response = array();
        // Edit a user
        if (isset($_POST["username"])
            && isset($_POST["password"])
            && isset($_POST["last_name"])
            && isset($_POST["first_name"])
            && isset($_POST["address"])
            && isset($_POST["status"])) {
            $username = $_POST["username"];
            $password = $_POST["password"];
            $last_name = $_POST["last_name"];
            $first_name = $_POST["first_name"];
            $address = $_POST["address"];
            $status = $_POST["status"];
            
            require_once __DIR__ . "/connect.php";
            
            $db = new Database_Connection();
            $connect = $db -> getLink();
            
            $result = mysqli_query($connect,"UPDATE users SET  WHERE username = '$username'");
            if ($result) {
                $response["success"] = true;
                $response["message"] = "Successfully edited a user";
            }
            else {
                $response["success"] = false;
                $response["message"] = "Failed to edit a user";
            }
            echo json_encode($response);
        }
        // Edit a restaurant
        else if (isset($_POST["restaurant_id"])
            && isset($_POST["restaurant_name"])
            && isset($_POST["cuisine"])
            && isset($_POST["street"])
            && isset($_POST["civic_number"])
            && isset($_POST["city"])) {
            $cuisine = $_POST["cuisine"];
            $street = $_POST["street"];
            $civic_number = $_POST["civic_number"];
            $city = $_POST["city"];
            
            require_once __DIR__ . "/connect.php";
            
            $db = new Database_Connection();
            $connect = $db -> getLink();
            
            $result = mysqli_query($connect,"UPDATE restaurants SET  WHERE restaurant_id = '$restaurant_id'");
            if ($result) {
                $response["success"] = true;
                $response["message"] = "Successfully edited a restaurant";
            }
            else {
                $response["success"] = false;
                $response["message"] = "Failed to edit a restaurant";
            }
            echo json_encode($response);
        }
        else if (isset($_POST["photo_id"])
            && isset($_POST["photo_title"]) 
            && isset($_POST["rating"])   
            && isset($_POST["image"])) {
            $photo_title = $_POST["photo_title"];
            $rating = floatval($_POST["rating"]);
            $data = $_POST["image"];
            //$data = base64_decode($data);
            $image = imagecreatefromstring($data);
            if ($image !== false) {
                imagepng($image);
                header("Content-type: image/png");
            }
            //imagepng($image);
            //header("Content-type: image/*");
            //$decodedImage = base64_decode($image);
            
            require_once __DIR__ . "/connect.php";
            
            $db = new Database_Connection();
            $connect = $db -> getLink();
            
            $result = mysqli_query($connect,"UPDATE photos SET  WHERE photo_id = '$photo_id'");
            if ($result) {
                $response["success"] = true;
                $response["message"] = "Successfully edited a photo";
            }
            else {
                $response["success"] = false;
                $response["message"] = "Failed to edit a photo";
            }
            imagedestroy($image);
            echo json_encode($response);
        }
        // Edit a publication
        else if (isset($_POST("publication_id")
            && isset($_POST["publication_date"])) {
            $publication_date = $_POST["publication_date"];
            
            require_once __DIR__ . "/connect.php";
            
            $db = new Database_Connection();
            $connect = $db -> getLink();
            
            $result = mysqli_query($connect,"UPDATE publications SET  WHERE publication_id = '$publication_id'");
            
            if ($result) {
                $response["success"] = true;
                $response["message"] = "Successfully edited a publication";
            }
            else {
                $response["success"] = false;
                $response["message"] = "Failed to edit a publication";
            }
            echo json_encode($response);
        }
        else {
            // Missing fields
            $response["message"] = "Required field(s) is missing";
            echo json_encode($response);
        }
        ?>
    </body>
</html>