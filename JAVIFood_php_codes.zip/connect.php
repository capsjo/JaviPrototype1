<html>
    <head>
    </head>
    <body>
        <?php
        class Database_Connection {
            private $link = null;
            
            // Constructor
            function __construct() {
                $this -> connect();
            }
            
            // Destructor
            function __destruct() {
                $this -> close();
            }
            
            // Function to return the link obtained after in $connect
            function getLink() {
                return $this -> link;
            }
            
            // Function to open connection
            function connect() {
                // Importing database connection variables
                require_once __DIR__ . "/config.php";
                
                // Connecting to Mysqli database
                $connect = mysqli_connect(server,username,password,database);
                $this -> link = $connect;
                if (!$connect) {
                    echo nl2br("Failed to connect to the server '" . server . "': " . mysqli_connect_error() . "\n");
                }
                else {
                    echo nl2br("Successfully connected to the server '" . server . "' \n");
                }
            }
            
            // Function to close connection
            function close() {
                // Closing database connection
                if (mysqli_close($this -> link)) {
                    echo nl2br("Successfully closed the connection\n");
                }
                else {
                    echo nl2br("Failed to close the connection\n");
                }
            }
        }
        ?>
    </body>
</html>