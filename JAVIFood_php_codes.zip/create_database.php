<html>
    <head>
    </head>
    <body>
        <?php
        // Array containing SQL statements to create tables
        $create = array(
            "User" => "CREATE TABLE User(
            username varchar(20) PRIMARY KEY NOT NULL,
            password varchar(20) NOT NULL,
            last_name varchar(20) NOT NULL,
            first_name varchar(20) NOT NULL,
            city varchar(30) NOT NULL,
            province varchar(30) NOT NULL,
            country varchar(30) NOT NULL,
            status varchar(20) NOT NULL);",
            "Photo" => "CREATE TABLE Photo(
            id int NOT NULL AUTO_INCREMENT,
            name varchar(25) NOT NULL,
            image blob NOT NULL,
            username varchar(20) NOT NULL,
            publication_date date NOT NULL,
            rating int(20) NOT NULL,
            description varchar(150) NOT NULL,
            restaurant_name varchar(50) NOT NULL,
            city varchar(50) NOT NULL,
            PRIMARY KEY(id),
            FOREIGN KEY (username) REFERENCES User(username));",
        );
        
        // Create the database
        $connect = mysqli_connect("mysql.iro.umontreal.ca","kounidol","XWTNXAW37zanhK");
        $db = "kounidol_javifood";
        $sql = "CREATE DATABASE " . $db;
        if (mysqli_query($connect,$sql)) {
            echo nl2br("Successfully created the database '$db'\n");
        }
        else {
            echo nl2br("Failed to create the database '$db'\n");
        }
        
        // Create the tables
        foreach($create as $key => $statement) {
            $connect = mysqli_connect("mysql.iro.umontreal.ca","kounidol","XWTNXAW37zanhK",$db);
            $sql = $statement;
            if (mysqli_query($connect,$sql)) {
                echo nl2br("Successfully created the table '$key'\n");
            }
            else {
                echo nl2br("Failed to create the table '$key'\n");
            }
        }
        ?>
    </body>
</html>