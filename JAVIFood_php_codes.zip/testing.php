<html>
    <head></head>
    <body>
        <?php
        require_once __DIR__ . "/connect.php";
        $db = new Database_Connection();
        $connect = $db -> getLink();
        //$connect = mysqli_connect(server,username,password,database);
        if (!$connect) {
            echo nl2br("Failed to connect to DIRO database\n");
        }
        else {
            echo nl2br("Host information: " . mysqli_get_host_info($connect) . PHP_EOL . "\n");
        }
        ?>
    </body>
</html>