<html>
    <head>
    </head>
    <body>
        <?php
        $response = array();
        // Sign up
        if (isset($_POST["username"])
            && isset($_POST["password"])
            && isset($_POST["last_name"])
            && isset($_POST["first_name"])
            && isset($_POST["city"])
            && isset($_POST["province"])
            && isset($_POST["country"])) {
            $username = $_POST["username"];
            $password = $_POST["password"];
            $last_name = $_POST["last_name"];
            $first_name = $_POST["first_name"];
            $city = $_POST["city"];
            $province = $_POST["province"];
            $country = $_POST["country"];
            $status = "Novice";
            
            require_once __DIR__ . "/connect.php";
            
            $db = new Database_Connection();
            $connect = $db -> getLink();
            
            $users = mysqli_query($connect, "SELECT username FROM User where username = '$username'");
            if ($users) {
                $userInfo = mysqli_fetch_array($users, MYSQLI_ASSOC);
                $userConfirm = $userInfo["username"];
                if ($username == $userConfirm) {
                    $response["success"] = false;
                    $response["message"] = "Username is already taken";
                }
                else {
                    $result = mysqli_query($connect,"INSERT INTO User(username, password, last_name, first_name, city, province, country, status) VALUES('$username', '$password', '$last_name', '$first_name', '$city', '$province', '$country', '$status')");
                    if ($result) {
                        $response["success"] = true;
                        $response["message"] = "Account successfully created";
                    }
                    else {
                        $response["success"] = false;
                        $response["message"] = "Failed to create an account";
                    }
                }
            }
        }
        // Add a publication
        else if (isset($_POST["name"])
                 && isset($_POST["image"])
                 && isset($_POST["username"])
                 && isset($_POST["description"])
                 && isset($_POST["restaurant_name"])
                 && isset($_POST["city"])) {
            $name = $_POST["name"];
            $image = $_POST["image"];
            $username = $_POST["username"];
            $publication_date = date("Y-m-d");
            $rating = 0;
            $description = $_POST["description"];
            $restaurant_name = $_POST["restaurant_name"];
            $city = $_POST["city"];
            
            /*$image_file = time().rand(1111,9999);
            $name = $name.$image_file;
            $base_path = "/home/www-ens/kounidol/public_html/uploads/";
            file_put_contents($base_path.$name.".jpg", $decodedimg);*/
            //$image = $_POST["image"];
            
            require_once __DIR__ . "/connect.php";
            
            $db = new Database_Connection();
            $connect = $db -> getLink();
            $truePath = "http://www-ens.iro.umontreal.ca/~kounidol/";
            
            $result1 = mysqli_query($connect,"INSERT INTO Photo(name, image, username, publication_date, rating, description, restaurant_name, city) VALUES('$name', '$truePath','$username','$publication_date','$rating','$description','$restaurant_name','$city');");
            if ($result1) {
                $id = mysqli_insert_id($connect);
                $photo = $name . $id;
                $path = "uploads/$photo.jpg";
                $truePath = $truePath . $path;
                $result2 = mysqli_query($connect, "UPDATE Photo SET image = '$truePath' WHERE id = '$id';");
                if ($result2) {
                    file_put_contents($path,base64_decode($image));
                    $response["success"] = true;
                    $response["message"] = "Successfully added a photo";
                    $permission = chmod($path, 0644);
                    if ($permission) {
                        $response["permission"] = true;
                        $response["access"] = "Photo can be accessed";
                    }
                    else {
                        $response["permission"] = false;
                        $response["access"] = "Photo cannot be accessed";
                    }
                }
            }
            else {
                $response["success"] = false;
                $response["message"] = "Failed to add a photo";
                $response["name"] = $name;
                $response["image"] = $image;
                $response["username"] = $username;
                $response["description"] = $description;
                $response["restaurant_name"] = $restaurant_name;
                $response["city"] = $city;
                /*$response["name"] = $name;
                //$response["image"] = $name;
                $response["username"] = $username;
                $response["datePub"] = $datePub;
                $response["rating"] = $rating;
                $response["nomResto"] = $nomResto;
                $reponse["ville"] = $ville*/;
                //$response["imgbase64"] = $img;
                //$response["imgstring"] = $image;
            }
        }
        // Missing fields
        else {
            $response["message"] = "Required field(s) is missing";
        }
        echo json_encode($response);
        ?>
    </body>
</html>